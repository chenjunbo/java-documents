package xin.chenjunbo.order.controller;


//
//                            _ooOoo_  
//                           o8888888o  
//                           88" . "88  
//                           (| -_- |)  
//                            O\ = /O  
//                        ____/`---'\____  
//                      .   ' \\| |// `.  
//                       / \\||| : |||// \  
//                     / _||||| -:- |||||- \  
//                       | | \\\ - /// | |  
//                     | \_| ''\---/'' | |  
//                      \ .-\__ `-` ___/-. /  
//                   ___`. .' /--.--\ `. . __  
//                ."" '< `.___\_<|>_/___.' >'"".  
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |  
//                 \ \ `-. \_ __\ /__ _/ .-` / /  
//         ======`-.____`-.___\_____/___.-`____.-'======  
//                            `=---='  
//  
//         .............................................  
//                  佛祖镇楼            BUG辟易  
//          佛曰:  
//                  写字楼里写字间，写字间里程序员；  
//                  程序人员写程序，又拿程序换酒钱。  
//                  酒醒只在网上坐，酒醉还来网下眠；  
//                  酒醉酒醒日复日，网上网下年复年。  
//                  但愿老死电脑间，不愿鞠躬老板前；  
//                  奔驰宝马贵者趣，公交自行程序员。  
//                  别人笑我忒疯癫，我笑自己命太贱；  


import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import xin.chenjunbo.order.entity.Order;
import xin.chenjunbo.order.handler.MyBlockHandler;
import xin.chenjunbo.order.handler.MyFallbackHandler;

/**
 * Created on 2023/7/17 20:38
 *
 * @author jackiechan
 */
@RestController
@RequestMapping("/orders")
@RefreshScope
public class OrderController {

    @Value("${order.server.tag}")
    private String tag;

    @GetMapping("order/{id}")
    public Order getOrderById(@PathVariable Long id) {
        Order order = new Order();
        order.setOId(id);
        order.setTitle("测试标题" + id);

        return order;
    }

    @GetMapping("/tag")
    public String getTag() {
        return tag;
    }

    /*
    value为资源名,fallbackClass指的是fallback方法所在的类,blockHandler为被限流的时候执行的方法的名字,fallback在代码出现异常的时候执行的方法的名字
    blockHandlerClass是指的blockHandler方法所在的类,fallbackClass是fallback方法所在的类
     */
    @GetMapping("/sentinel1/{ex}")
    @SentinelResource(value = "getOrderSentinel", blockHandler = "test4BlockHandler" ,blockHandlerClass = {MyBlockHandler.class},fallback = "test4Fallback",fallbackClass ={MyFallbackHandler.class} ,exceptionsToIgnore ={ArithmeticException.class} )
//    @SentinelResource(value = "getOrderSentinel",fallback = "getOrderSentinelfallback",blockHandler = "getOrderSentinelblock")
    public Order getOrderSentinel(@PathVariable int ex) {

        int i = 1 / ex;
        return new Order();
    }


    @GetMapping("/sentinel2/{ex}")
//    @SentinelResource(value = "getOrderSentinel",fallback = "getOrderSentinelfallback",blockHandler = "getOrderSentinelblock")
    public Order testExp(@PathVariable int ex) {
        int i = 1 / ex;
        return new Order();
    }
    /**
     * 当前方法的参数列表顺序和正常方法保持一致,返回值保持一致
     * @param ex
     * @return
     */
    public Order getOrderSentinelfallback( int ex) {
        Order order = new Order();
        order.setTitle("getOrderSentinelfallback");
        order.setOId((long) -100);
        return order;
    }

    /**
     * block 的参数必须包含BlockException异常类型
     * @param blockException
     * @return
     */
    public Order getOrderSentinelblock( int ex,BlockException blockException) {

        Order order = new Order();
        order.setTitle("getOrderSentinelblock"+blockException.getMessage());
        order.setOId((long) -200);
        return order;
    }
}

<template>
    <div>商品列表 商品的id:{{id}}</div>
</template>

<script>
export default {
    name: "Product",
    data(){
      return{
        id:this.$route.params.id //接参
      }
    }
}
</script>

<style scoped>

</style>

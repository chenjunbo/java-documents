<template>
    <div>欢迎你！{{user.name}}</div>
</template>

<script>
export default {
    name: "Home",
    data(){
      return {
        user:this.$store.getters.getUser
      }
    }
}
</script>

<style scoped>

</style>
